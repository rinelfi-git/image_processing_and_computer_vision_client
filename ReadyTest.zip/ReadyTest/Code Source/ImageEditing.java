public class ImageEditing{
    public static void main(String[] args){
        new PicFrame();
    }
}