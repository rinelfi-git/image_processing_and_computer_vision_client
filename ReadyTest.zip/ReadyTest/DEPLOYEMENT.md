**Methode de déployement du logiciel**
```
Dans le dossier principal contenant le projet, il y a 3 sous-dossiers parmi lesquels, on a :
    - Code Source : ce dossier contient le code source du logiciel (les fonctions, le code source de l'affichage de la fenêtre).
    - Executable : il contient le fichier .exe et .jar prêt à l'exécution.
NB : Il faut verrifier que JDK version 8 est bien installé dans votre machine. Pour celà :
    1- Allez dans Panneau de Configuration -> Système et Sécurité -> Système -> Paramètres système avancés -> Variables d'environnements.
    2- Vérifier si la variable "JAVA_HOME" contient bien le chemain vers jdk 8, sinon, définissez-la avec la valeur
        "C:\Program files\Java\nomDuRepertoireDuJDK8".
    3- Lancez l'application contenu dans le repertoire "Executable" (le fichier ImageEditingv1.2.3.exe ou ImageEditing.jar) pour vérifier si elle fonctionne. Normalement, elle doit fonctionner.
```

**NB**
La fenêtre du logiciel est figée par défaut, donc il est impossible de zoomer l'image. Du coup, quand vous lancez le traitement "contour" d'image, il serait préférable d'enregistrer d'abord l'image (automatiquement enregistré dans votre dossier "Picture"), et d'utiliser une visionneuse d'image qui permet de zoomer l'image, afin de bien observer le résultat de l'algorithme de contour.